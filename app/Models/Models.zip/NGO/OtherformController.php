<?php

namespace App\Models\NGO;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OtherformController extends Model
{
    use HasFactory;
}
